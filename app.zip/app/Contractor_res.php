<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contractor_res extends Model
{
    //
    protected $table = 'contractor_res_quar';

    protected $fillable=[
    	'contractor_id','res_quar_id'
    ];

    
}
