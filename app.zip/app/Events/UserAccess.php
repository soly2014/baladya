<?php

namespace App\Events;

class UserAccess extends Event
{
    //
}
