<?php

namespace App\Repositories\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface FacilityRepository
 * @package namespace App\Repositories\Interfaces;
 */
interface FacilityRepository extends RepositoryInterface
{
    //
}
