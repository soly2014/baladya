<?php

namespace App\Repositories\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserRepositoryRepository
 * @package namespace App\Repositories\Interfaces;
 */
interface UserRepositoryRepository extends RepositoryInterface
{
    //
}
