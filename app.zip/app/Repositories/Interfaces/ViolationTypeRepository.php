<?php

namespace App\Repositories\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ViolationTypeRepository
 * @package namespace App\Repositories\Interfaces;
 */
interface ViolationTypeRepository extends RepositoryInterface
{
    //
}
