<?php

namespace App\Repositories\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserVisitRepository
 * @package namespace App\Repositories\Interfaces;
 */
interface UserVisitRepository extends RepositoryInterface
{
    //
}
