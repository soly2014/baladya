<?php

namespace App\Repositories\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface HealthEnvTypeRepository
 * @package namespace App\Repositories\Interfaces;
 */
interface HealthEnvTypeRepository extends RepositoryInterface
{
    //
}
