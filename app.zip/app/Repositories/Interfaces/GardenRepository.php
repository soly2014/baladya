<?php

namespace App\Repositories\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface GardenRepository
 * @package namespace App\Repositories\Interfaces;
 */
interface GardenRepository extends RepositoryInterface
{
    //
}
