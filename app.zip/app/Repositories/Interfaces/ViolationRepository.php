<?php

namespace App\Repositories\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ViolationRepository
 * @package namespace App\Repositories\Interfaces;
 */
interface ViolationRepository extends RepositoryInterface
{
    //
}
