<?php

namespace App\Repositories\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface FacilityStatusRepository
 * @package namespace App\Repositories\Interfaces;
 */
interface FacilityStatusRepository extends RepositoryInterface
{
    //
}
