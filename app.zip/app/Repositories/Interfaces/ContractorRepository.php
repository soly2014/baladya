<?php

namespace App\Repositories\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ContractorRepository
 * @package namespace App\Repositories\Interfaces;
 */
interface ContractorRepository extends RepositoryInterface
{
    //
}
