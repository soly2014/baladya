<?php

namespace App\Repositories\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface StreetRepository
 * @package namespace App\Repositories\Interfaces;
 */
interface StreetRepository extends RepositoryInterface
{
    //
}
