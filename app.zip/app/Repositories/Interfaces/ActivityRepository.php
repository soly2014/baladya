<?php

namespace App\Repositories\Interfaces;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ActivityRepository
 * @package namespace App\Repositories\Interfaces;
 */
interface ActivityRepository extends RepositoryInterface
{
    //
}
