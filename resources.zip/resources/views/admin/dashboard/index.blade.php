@extends('layouts.template')
@section('content')		

<div class="main-content">

    <div class="row">

        <!-- Profile Info and Notifications -->
        <div class="col-md-6 col-sm-8 clearfix">

        </div>

    </div>



    <!-- Footer -->
    <footer class="main">


    </footer>
</div>

@stop