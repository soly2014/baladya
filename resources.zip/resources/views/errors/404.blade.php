@extends('errors.layout')

@section('content')
	@include('errors.partial', ['number' => '404'])
@endsection
